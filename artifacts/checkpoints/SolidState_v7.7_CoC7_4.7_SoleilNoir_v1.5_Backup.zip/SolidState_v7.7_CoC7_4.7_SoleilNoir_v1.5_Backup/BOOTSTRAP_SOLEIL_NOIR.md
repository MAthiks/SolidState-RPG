# RESTAURATION — SOLID STATE + SOLEIL NOIR

Baseline :
- Solid State v7.7
- CoC7 Rules Core v4.7
- Le Soleil Noir de Tobrouk v1.5 Multiplayer
- Paire documentaire : LSNT-V1.5-MULTI-1942

Ordre :
1. Charger le checkpoint v7.7 / 4.7.
2. Charger le Rules Core canonique 4.7 et vérifier son hash.
3. Charger `Le_Soleil_Noir_de_Tobrouk_v1.5_Multiplayer_Gardien.pdf`.
4. Charger `Le_Soleil_Noir_de_Tobrouk_v1.5_Multiplayer_Joueur.pdf`.
5. Vérifier :
   - LSNT-GARDIEN-V1.5-MULTI-1942
   - LSNT-JOUEUR-V1.5-MULTI-1942
   - LSNT-V1.5-MULTI-1942
6. Ne lancer aucune scène canonique si la paire n'est pas réellement consultable.
7. Les fichiers vérifiés priment sur la mémoire du chat.
8. Ne jamais rétrograder silencieusement.

IMPORTANT :
Les PDF v1.5 Gardien/Joueur sont référencés dans ce backup mais non embarqués,
car leurs octets bruts ne sont pas montés dans l'environnement de création.
